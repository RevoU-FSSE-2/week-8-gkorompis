var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
console.log("app routes for api gateway");
import cors from 'cors';
import express from 'express';
import bodyParser from 'body-parser';
export const handler = (event) => __awaiter(void 0, void 0, void 0, function* () {
    //express
    const app = express();
    console.log(">>>", event);
    //middlewares
    app.use(bodyParser.json({ limit: "30mb" }));
    app.use(bodyParser.urlencoded({ limit: "30mb", extended: true }));
    app.use(cors());
    //get routes
    app.get("/test1", (req, res) => {
        console.log(">>>async works", { req, res });
        res.status(200).json({
            statusCode: 200,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ message: "this lambda async get route works" })
        });
    });
    // const PORT = process.env.PORT || 3000;
    // return await (async ()=>{
    //     app.listen(0, () => {
    //     console.log(`Server is running asynchronously on port 0`);
    //     return {
    //     statusCode: 200,
    //     body: JSON.stringify({ message: 'Lambda executed successfully try 2' })
    // };})
    // })();
    console.log('try 4');
    // return async  () =>{
    //     return  {
    //         statusCode: 200,
    //         body: JSON.stringify({ message: 'Lambda executed successfully try 3' })
    //     }
    // }
    // return {
    //     statusCode: 200,
    //     body: JSON.stringify({ message: 'Lambda executed successfully try 2' })
    // };
    return new Promise((resolve, reject) => {
        app.listen(0, (error) => {
            if (error) {
                reject(error);
            }
            else {
                console.log(`Server is running on port 0`);
                resolve({
                    statusCode: 200,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: "Server is running" })
                });
            }
        });
    });
    ;
});
