// loadEnv.js
import dotenv from 'dotenv';
dotenv.config()